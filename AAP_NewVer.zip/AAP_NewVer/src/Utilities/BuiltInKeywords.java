package Utilities;

import java.util.concurrent.TimeUnit;

import AnyAut_Orange.ChromeDriver;
import AnyAut_Orange.FirefoxDriver;
import AnyAut_Orange.InternetExplorerDriver;
import AnyAut_Orange.PhantomJSDriver;
import AnyAut_Orange.SafariDriver;
import AnyAut_Orange.UICode;
import AnyAut_Orange.Utilities;

public class BuiltInKeywords {

	public void openBrowser(String browserType) {
		// Purpose: Open a Browser, Timeout
		// I/P : which Browser
		// o/p : N/A
		/*
		 * Updated By:Aparna Date: 11/16/2016 Purpose:updated the .exe filepaths
		 */
		
		int browserTimeout = 0;
		String strTimeout = new UICode().returnValues("BrowserTimeOut");
		
		
		if (strTimeout.length() > 0) {
			browserTimeout = Integer.valueOf(strTimeout);
		}else {
			browserTimeout = 10;
		}
		
		try {
			switch (browserType) {
			case "Firefox":
				if (System.getProperty("os.name").contains("Windows")) {
					System.setProperty("webdriver.gecko.driver", Utilities.fileAbsolutePath() + "Browsers/Win/geckodriver.exe");
					//Thread.sleep(10000);
				}else {
					System.setProperty("webdriver.gecko.driver", Utilities.fileAbsolutePath() + "Browsers/Mac/geckodriver");
				}
				driver = new FirefoxDriver();
				break;
				
			case "Chrome":
					System.out.println("Entered Chrome browser case");
					if (System.getProperty("os.name").contains("Windows")) {
						System.setProperty("webdriver.chrome.driver", Utilities.fileAbsolutePath() + "Browsers/Win/chromedriver.exe");
						Thread.sleep(10000);
					}else {
				    	System.setProperty("webdriver.chrome.driver", Utilities.fileAbsolutePath() + "Browsers/Mac/chromedriver");
				    }
					driver = new ChromeDriver();
					System.out.println(driver);
					break;
			case "IE":
				System.setProperty("webdriver.ie.driver", Utilities.fileAbsolutePath() + "Browsers/Win/IEDriverServer.exe");
				driver = new InternetExplorerDriver();
				break;
			case "Safari":
				driver = new SafariDriver();
				break;
			case "PhantomJS":
				   System.setProperty("phantomjs.binary.path", Utilities.fileAbsolutePath() + "Browsers/Win/phantomjs.exe");  
				   driver = new PhantomJSDriver();
				break;
			default:
				driver = new ChromeDriver();
	
			}
		}catch(Exception ex) {
			logger.error("Error occured while initializing the browser drivers " + ex);
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(browserTimeout, TimeUnit.SECONDS);

	}

}
