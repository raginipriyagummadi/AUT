import java.util.ArrayList;
import java.util.Scanner;
/*
 *	Purpose: Runs the sets of Parallel Execution of Unique Test Cases (UTC) using Threading concept.  
 *			 Runs before ExecuteRun.java and after PrepareRun.java
 * 	input  : UTC
 *  output : 
 *  
 * */

public class Turbo {
	

	public static void main(String args[]) throws InterruptedException 
	{
		Runnable task1 = () -> {
			System.out.println("Start 1 ");
			try 
			{
				Thread.sleep(1000);
				System.out.println("End 1");
			}
			catch(InterruptedException e) 
			{
				System.out.println("Exception ::"+e.getMessage());
			}
		};
		
		Runnable task2 = () -> {
			System.out.println("Start 2");
			try 
			{
				Thread.sleep(2000);
				System.out.println("End 2");
			}
			catch(InterruptedException e) 
			{
				System.out.println("Exception ::"+e.getMessage());
			}
		};
	
		Runnable task3 = () -> {
			System.out.println("Start 3");
			try 
			{
				Thread.sleep(3000);
				System.out.println("End 3");
			}
			catch(InterruptedException e) 
			{
				System.out.println("Exception ::"+e.getMessage());
			}
		};
		
		Runnable task4 = () -> {
			System.out.println("Start 4");
			try 
			{
					Thread.sleep(4000);
					System.out.println("End 4");
			}
			catch(InterruptedException e) 
			{
				System.out.println("Exception ::"+e.getMessage());
			}
		};
		
		Runnable task5 = () -> {
			System.out.println("Start 5");
			try 
			{
					Thread.sleep(5000);
					System.out.println("End 5");
			}
			catch(InterruptedException e) 
			{
				System.out.println("Exception ::"+e.getMessage());
			}
		};
		
		Runnable task6 = () -> {
			System.out.println("Start 6");
			try 
			{
					Thread.sleep(6000);
					System.out.println("End 6");
			}
			catch(InterruptedException e) 
			{
				System.out.println("Exception ::"+e.getMessage());
			}
		};
		
		Runnable task7 = () -> {
			System.out.println("Start 7");
			try 
			{
					Thread.sleep(7000);
					System.out.println("End 7");
			}
			catch(InterruptedException e) 
			{
				System.out.println("Exception ::"+e.getMessage());
			}
		};
		Runnable task8 = () -> {
			System.out.println("Start 8");
			try 
			{
					Thread.sleep(8000);
					System.out.println("End 8");
			}
			catch(InterruptedException e) 
			{
				System.out.println("Exception ::"+e.getMessage());
			}
		};
		
		
		Scanner in = new Scanner(System.in);
		long startTime = System.currentTimeMillis();
		
		System.out.println("Start!");
		
		
		ArrayList<Thread> threadListTC = new ArrayList<Thread>(10);
		
		Thread thread1 = new Thread(task1);
		threadListTC.add(thread1);
		Thread thread2 = new Thread(task2);
		threadListTC.add(thread2);
		Thread thread3 = new Thread(task3);
		threadListTC.add(thread3);
		Thread thread4 = new Thread(task4);
		threadListTC.add(thread4);
		Thread thread5 = new Thread(task5);
		
		threadListTC.add(thread5);
		Thread thread6 = new Thread(task6);
		threadListTC.add(thread6);
		Thread thread7 = new Thread(task7);
		threadListTC.add(thread7);
		Thread thread8 = new Thread(task8);
		threadListTC.add(thread8);
		

		int numUTC = threadListTC.size();
		int  numThread= 0;
		do 
		{
			System.out.println("Enter how many Threads you want to run at a time provide less than "+ numUTC+ " ?");
			numThread= in.nextInt();
		} 
		while(numThread > numUTC);
		
			int nCounter = 0;
			
			int nLoops = Math.round(numUTC/numThread);
			int nWhileLoopChecker = 0;
			
			try
			{
				while (nWhileLoopChecker<nLoops)
				{	
				
					for(int j = nWhileLoopChecker; j<numThread; j++)
					{
						threadListTC.get(nCounter).start();
						nCounter++;// 3
					}
					
					nCounter-=numThread; 
					
					
					for(int j = nWhileLoopChecker; j<numThread; j++)
					{
						threadListTC.get(nCounter).join();
						nCounter++; 
					}
				}
			}catch(Exception e)
			{
				threadListTC.get(threadListTC.size()-1).join();
			}
			
			
			System.out.println("Done!");
			
			long endTime = System.currentTimeMillis();
			System.out.println("Time taken: "+((endTime- startTime)/1000 )+" sec" );
			
			 in.close();
		
	}
}
